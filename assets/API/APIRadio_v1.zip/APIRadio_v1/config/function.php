<?php
    function Normalisasi($val, $max, $min){
        $xy = (0.8 * ($val - $min) / ($max - $min)) + 0.1;
        return $xy;
    }

    function Denormalisasi($val, $max, $min){
        $xy = ((($val - 0.1) * ($max - $min)) + (0.8 * $min)) / 0.8;
        return $xy;
    }

    function sigmoid($t){
        $xy = 1 / (1 + exp(-$t));
        return $xy;
    }

    function bacaURL($url){		
		$session = curl_init(); // buat session		
		// setting CURL		
		curl_setopt($session, CURLOPT_URL, $url);
		curl_setopt($session, CURLOPT_HEADER, 0);
		curl_setopt($session, CURLOPT_RETURNTRANSFER, 1);
		$hasil = curl_exec($session);
		curl_close($session);
		return $hasil;
    }
    
    function fnGetQRYMaxMin($con, $MaxMin, $idReg, $dt){
        $xx = 
            "SELECT harga, tgl as tgl
            FROM ( 
                SELECT ".$MaxMin."(tgl) AS maxdate 
                FROM tbl_tempharga t 
                WHERE 
                t.id_region = ".$idReg." AND
                t.tgl >= '".$dt." 00:00:00' AND t.tgl <= '".$dt." 23:59:59' AND
                t.harga <> 0
                GROUP BY YEAR(tgl), MONTH(tgl), WEEK(tgl), DAY(tgl)
            ) AS g 
            INNER JOIN tbl_tempharga t ON g.maxdate = t.tgl 
            WHERE 
            t.id_region = ".$idReg." AND
            t.tgl >= '".$dt." 00:00:00' AND t.tgl <= '".$dt." 23:59:59' AND
            t.harga <> 0
            ORDER BY tgl DESC
            LIMIT 1";

        $query = mysqli_query($con, $xx);
        if (mysqli_num_rows($query) > 0){
            while ($list = mysqli_fetch_array($query)) {
               $yy = $list['harga'];
            }
        } else {
            $yy = 0;
        }
        
        return $yy;
    }

    function fnInsertData($kon, $id_region, $tanggal, $value, $weight){
		$SQLAdd = 
			"INSERT INTO tbl_tempharga (id_region, tgl, harga, weight) VALUES ('".$id_region."', '".$tanggal."', '".$value."', '".$weight."')";

        if (mysqli_query($kon, $SQLAdd)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
    
    function fnGetDistAB($lat1, $long1, $lat2, $long2) {
        $diameter = 2 * 6372.8;
        $long1 = deg2rad($long1 - $long2);
        $lat1 = deg2rad($lat1);
        $lat2 = deg2rad($lat2);

        $dz = sin($lat1) - sin($lat2);
        $dx = cos($long1) * cos($lat1) - cos($lat2);
        $dy = sin($long1) * cos($lat1);
        return asin(sqrt(pow($dx, 2) + pow($dy, 2) + pow($dz, 2)) / 2) * $diameter;
    }

    function fnGetHashHMAC256($str, $sig){
        return hash_hmac("sha256", $str, $sig);
    }

    function fnExplode($str){
        $arr = explode(",", $str);

        $respon = "";
        for ($i = 0 ; $i < count($arr); $i++){
            if ($i == 0){
                $respon = $respon."'".$arr[$i]."'";
            } else {
                $respon = $respon.",'".$arr[$i]."'";
            }
        }

        return $respon;
    }

    function fnCheckData($kon, $tbl, $where){
        $SQLAdd = 
            "SELECT * FROM ".$tbl." WHERE ".$where;
        $query = mysqli_query($kon, $SQLAdd);
        if (mysqli_num_rows($query) > 0){
            return FALSE;
        } else {
            return TRUE;
        }
    }

    function fnDeleteItem($kon, $id, $nmTable){
        $index = 0;
        $SQLAdd =
            "DELETE FROM ".$nmTable." WHERE id = '".$id."'";

        if (mysqli_query($kon, $SQLAdd)) {
            return TRUE;
        } else {
            return FALSE;
        }
        
        #return $respon;
    }

    function fnDeleteSubItem($kon, $id, $sub, $nmTable){
        $index = 0;
        $SQLAdd =
            "DELETE FROM ".$nmTable." WHERE ".$sub." = '".$id."'";

        if (mysqli_query($kon, $SQLAdd)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function fnDeleteItemWhere($kon, $nmTable, $isWhere){
        $index = 0;
        $SQLAdd =
            "DELETE FROM ".$nmTable." WHERE ".$isWhere."";

        if (mysqli_query($kon, $SQLAdd)) {
            $respon[$index]['result'] = "SUKSES";
            $respon[$index]['pesan'] = 'DATA BERHASIL DI HAPUS';
        } else {
            $respon[$index]['result'] = "null";
            $respon[$index]['pesan'] = 'MAAF, DATA GAGAL HAPUS';
        }
        
        return $respon;
    }

    function fnInsertItem($kon, $tbl, $kol, $val){
        $index = 0;
        #$val = fnExplode($val);

		$SQLAdd =
            "INSERT INTO ".$tbl." (".$kol.") VALUES (".$val.")";

        if (mysqli_query($kon, $SQLAdd)) {
            $respon[$index]['result'] = "SUKSES";
            $respon[$index]['pesan'] = 'DATA BERHASIL DI INPUT';
        } else {
            $respon[$index]['result'] = "null";
            $respon[$index]['pesan'] = 'MAAF, DATA GAGAL INPUT';
        }
		
		return $respon;
	}

    function fnInsertItemIsNull($kon, $tbl, $kol, $val, $isWhere){
		$index = 0;
        #$val = fnExplode($val);

		$SQLAdd = 
			"SELECT * FROM ".$tbl." WHERE ".$isWhere;
		$query = mysqli_query($kon, $SQLAdd);
		if (mysqli_num_rows($query) > 0){
			$respon[$index]['result'] = "null";
            $respon[$index]['pesan'] = 'Already exist';
		} else {
			$SQLAdd =
                "INSERT INTO ".$tbl." (".$kol.") VALUES (".$val.")";

			if (mysqli_query($kon, $SQLAdd)) {
				$respon[$index]['result'] = "SUKSES";
                $respon[$index]['pesan'] = 'Data Success Input';
			} else {
				$respon[$index]['result'] = "null";
                $respon[$index]['pesan'] = 'Sorry, Data Failed to Input';
                #$respon[$index]['SQL'] = $SQLAdd;
			}
		}
		
		return $respon;
	}

    function fnInsertItemIsNotNull($kon, $tbl, $kol, $val, $isWhere){
		$index = 0;
        #$val = fnExplode($val);

		$SQLAdd = 
			"SELECT * FROM ".$tbl." WHERE ".$isWhere;
		$query = mysqli_query($kon, $SQLAdd);
		if (mysqli_num_rows($query) == 0){
			$respon[$index]['result'] = "null";
            $respon[$index]['pesan'] = 'Already exist';
		} else {
			$SQLAdd =
                "INSERT INTO ".$tbl." (".$kol.") VALUES (".$val.")";

			if (mysqli_query($kon, $SQLAdd)) {
				$respon[$index]['result'] = "SUKSES";
                $respon[$index]['pesan'] = 'DATA BERHASIL DI INPUT';
			} else {
				$respon[$index]['result'] = "null";
                $respon[$index]['pesan'] = 'MAAF, DATA GAGAL INPUT';
			}
		}
		
		return $respon;
	}

    function fnUpdateItem($kon, $tbl, $val, $isWHere){
		$index = 0;

		$SQLAdd =
            "UPDATE ".$tbl." SET ".$val." WHERE ".$isWHere;

        if (mysqli_query($kon, $SQLAdd)) {
            $respon[$index]['result'] = "SUKSES";
            $respon[$index]['pesan'] = 'DATA BERHASIL DI UBAH';
        } else {
            $respon[$index]['result'] = "null";
            $respon[$index]['pesan'] = 'MAAF, DATA GAGAL UBAH';
        }
		
		return $respon;
	}

    function fnUpdateItemIsNull($kon, $tbl, $val, $id, $isWhere){
		$index = 0;

		$SQLAdd = 
			"SELECT * FROM ".$tbl." WHERE ".$isWhere." AND id NOT IN ('".$id."')";
		$query = mysqli_query($kon, $SQLAdd);
		if (mysqli_num_rows($query) > 0){
			$respon[$index]['result'] = "null";
            $respon[$index]['pesan'] = 'Already exist';
		} else {
			$SQLAdd =
                "UPDATE ".$tbl." SET ".$val." WHERE id = '".$id."'";

            #echo $SQLAdd;

			if (mysqli_query($kon, $SQLAdd)) {
				$respon[$index]['result'] = "SUKSES";
                $respon[$index]['pesan'] = 'DATA BERHASIL DI INPUT';
			} else {
				$respon[$index]['result'] = "null";
                $respon[$index]['pesan'] = 'MAAF, DATA GAGAL INPUT';
			}
		}
		
		return $respon;
	}

    function fnUpdateItemIsNotNull($kon, $tbl, $val, $id, $isWhere){
		$index = 0;

		$SQLAdd = 
			"SELECT * FROM ".$tbl." WHERE ".$isWhere;
		$query = mysqli_query($kon, $SQLAdd);
		if (mysqli_num_rows($query) == 0){
			$respon[$index]['result'] = "null";
            $respon[$index]['pesan'] = 'Already exist';
		} else {
			$SQLAdd =
                "UPDATE ".$tbl." SET ".$val." WHERE id = '".$id."'";

			if (mysqli_query($kon, $SQLAdd)) {
				$respon[$index]['result'] = "SUKSES";
                $respon[$index]['pesan'] = 'DATA BERHASIL DI INPUT';
			} else {
				$respon[$index]['result'] = "null";
                $respon[$index]['pesan'] = 'MAAF, DATA GAGAL INPUT';
			}
		}
		
		return $respon;
    }

    function sendPush($to, $title, $body, $icon, $url) {
        #define('FCM_AUTH_KEY', 'AAAAN0hHhzM:APA91bHfeRCf5c5-rOI839LnFc6lvuCYT_kzk6F4L-8jU76Ilm_rHDitNUCGgopkTqBqeGa3KoT1yShkpCDYbcygsPbNLSdTuJ3_tnVuR5ff-GEKB1eqv_5TyF_n5e0WJ7CXsa2gzSzY');
        $FCM_AUTH_KEY = 'AAAAN0hHhzM:APA91bHfeRCf5c5-rOI839LnFc6lvuCYT_kzk6F4L-8jU76Ilm_rHDitNUCGgopkTqBqeGa3KoT1yShkpCDYbcygsPbNLSdTuJ3_tnVuR5ff-GEKB1eqv_5TyF_n5e0WJ7CXsa2gzSzY'; 
        $postdata = json_encode(
            [
                'notification' => 
                    [
                        'title' => $title,
                        'body' => $body,
                        'icon' => $icon,
                        'click_action' => $url,
                        'target' => 'com.blangkon.PredEmas'
                    ]
                ,
                'to' => $to
            ]
        );
    
        $opts = array('http' =>
            array(
                'method'  => 'POST',
                'header'  => 'Content-type: application/json'."\r\n"
                            .'Authorization: key='.$FCM_AUTH_KEY."\r\n",
                'content' => $postdata
            )
        );
    
        $context  = stream_context_create($opts);
    
        $result = file_get_contents('https://fcm.googleapis.com/fcm/send', false, $context);

        if ($result) {
            return json_decode($result);
        } else {
            return "Gagal";//false;
        }
    }
    
	
?>