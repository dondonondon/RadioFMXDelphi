<?php
    include_once 'function.php';
	
    function fnLoadEmas($kon){
		$index = 0;
		
		$SQLAdd =
			"SELECT sa.*, ge.nm_gedung FROM tbl_saran sa
			LEFT JOIN tbl_gedung ge ON ge.id = sa.id_gedung ORDER BY cdt DESC";

		$query = mysqli_query($kon, $SQLAdd);

		if (mysqli_num_rows($query) > 0){
			while ($list = mysqli_fetch_assoc($query)) {
				$respon[] = $list;
			}
		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'MAAF, BELUM ADA DATA';	
		}

		return $respon;
	}
	
    function fnLogin($kon, $user, $password){
		$index = 0;
		
		$SQLAdd =
			"SELECT * FROM tbl_user WHERE username = '".$user."' AND aplikasi = 'PredGoldStock'";

		$query = mysqli_query($kon, $SQLAdd);

		if (mysqli_num_rows($query) > 0){
			$SQLAdd =
				"SELECT * FROM tbl_user WHERE username = '".$user."' AND password = '".$password."' AND aplikasi = 'PredGoldStock'";
			$qPassword = mysqli_query($kon, $SQLAdd);
			if (mysqli_num_rows($qPassword) > 0){
				while ($list = mysqli_fetch_array($qPassword)) {
					$respon[$index]['result'] = 'success';	
					$respon[$index]['id'] = $list['id_user'];	
					$respon[$index]['username'] = $list['username'];	
					$respon[$index]['leveluser'] = $list['leveluser'];	
				}
			} else {
				$respon[$index]['result'] = 'null';	
				$respon[$index]['pesan'] = 'The password you entered is incorrect';	
			}
		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'The username you entered is incorrect';	
		}

		return $respon;
	}
	
    function fnLoadRadio($kon){
		$index = 0;
		
		$SQLAdd =
			"SELECT * FROM tbl_radio";

		$query = mysqli_query($kon, $SQLAdd);

		if (mysqli_num_rows($query) > 0){
			while ($list = mysqli_fetch_assoc($query)) {
				$respon[] = $list;
			}
		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'MAAF, BELUM ADA DATA';	
		}

		return $respon;
	}
	
    function fnLoadRadioLimit($kon, $limit){
		$index = 0;
		
		$SQLAdd =
			"SELECT * FROM tbl_radio LIMIT ".$limit;

		$query = mysqli_query($kon, $SQLAdd);

		if (mysqli_num_rows($query) > 0){
			while ($list = mysqli_fetch_assoc($query)) {
				$respon[] = $list;
			}
		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'MAAF, BELUM ADA DATA';	
		}

		return $respon;
	}
	
    function fnGetSetting($kon){
		$index = 0;

		$SQLAdd = 
			"SELECT * FROM tbl_setting";

		$query = mysqli_query($kon, $SQLAdd);

		if (mysqli_num_rows($query) > 0){
			while ($list = mysqli_fetch_array($query)) {
				$respon[$index][$list['jenis']] = $list['value'];
			}
		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'No Predict history';	
		}

		return $respon;
	}
	
    function fnMyFavorite($kon, $id_device){
		$index = 0;
		
		$SQLAdd =
				"SELECT ra.* FROM tbl_radio ra
				LEFT JOIN tbl_favorite fa ON fa.id_radio = ra.id
				LEFT JOIN tbl_device_id dev ON dev.id = fa.id_user
				WHERE dev.fcm = '".$id_device."' ORDER BY favorite DESC LIMIT 10";

		$query = mysqli_query($kon, $SQLAdd);

		if (mysqli_num_rows($query) > 0){
			while ($list = mysqli_fetch_assoc($query)) {
				$respon[] = $list;
			}
		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'Maaf, Anda belum menambahkan channel favorit anda';	
		}

		return $respon;
	}
	
    function fnFavorite($kon){
		$index = 0;
		
		$SQLAdd =
				"SELECT * FROM tbl_radio ORDER BY favorite DESC LIMIT 10";

		$query = mysqli_query($kon, $SQLAdd);

		if (mysqli_num_rows($query) > 0){
			while ($list = mysqli_fetch_assoc($query)) {
				$respon[] = $list;
			}
		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'MAAF, BELUM ADA DATA';	
		}

		return $respon;
	}
	
    function fnFindRadio($kon, $keyword){
		$index = 0;
		$SQLAdd =
			"SELECT * FROM tbl_radio WHERE status = 1 AND
			radio_name LIKE '%".$keyword."%' OR radio_id LIKE '%".$keyword."%' ORDER BY radio_name ASC LIMIT 10";

		$query = mysqli_query($kon, $SQLAdd);
		if (mysqli_num_rows($query) > 0){
			while ($list = mysqli_fetch_array($query)) {
				$respon[$index]['id'] = $list['id'];
				$respon[$index]['radio_id'] = $list['radio_id'];
				$respon[$index]['radio_name'] = $list['radio_name'];

				$respon[$index]['radio_img'] = $list['radio_img'];
				$respon[$index]['stream_url'] = $list['stream_url'];
				$respon[$index]['stream_type'] = $list['stream_type'];
				$respon[$index]['favorite'] = $list['favorite'];
				$respon[$index]['status'] = $list['status'];

				$index++;
			}

			if ($index != 0) {
				$SQLAdd =
					"SELECT * FROM (SELECT * FROM tbl_radio WHERE  status = 1 AND
					SOUNDEX(radio_name) LIKE SOUNDEX('%".$keyword."%') OR radio_id LIKE '%".$keyword."%' ORDER BY radio_name ASC LIMIT 25) temp
					WHERE radio_name NOT IN (SELECT radio_name FROM tbl_radio WHERE status = 1 AND
					radio_name LIKE '%".$keyword."%' OR radio_id LIKE '%".$keyword."%' ORDER BY radio_name ASC) AND radio_id NOT IN (SELECT radio_id FROM tbl_radio WHERE status = 1 AND
					radio_name LIKE '%".$keyword."%' OR radio_id LIKE '%".$keyword."%' ORDER BY radio_name ASC) LIMIT 25";

				$query = mysqli_query($kon, $SQLAdd);
				if (mysqli_num_rows($query) > 0){
					while ($list = mysqli_fetch_array($query)) {
						$respon[$index]['id'] = $list['id'];
						$respon[$index]['radio_id'] = $list['radio_id'];
						$respon[$index]['radio_name'] = $list['radio_name'];

						$respon[$index]['radio_img'] = $list['radio_img'];
						$respon[$index]['stream_url'] = $list['stream_url'];
						$respon[$index]['stream_type'] = $list['stream_type'];
						$respon[$index]['favorite'] = $list['favorite'];
						$respon[$index]['status'] = $list['status'];

						$index++;
					}
				}
			}

		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'data '.$keyword.' tidak ditemukan';	
		}

		return $respon;
	}

	
	
    function fnLoadHome($kon, $id_device){
		$tg = date(' l, d M Y H:i:s');
		$tgl = date('Y-m-d H:i:s', strtotime('+7 hours',strtotime($tg)));


		$index = 0;
		$SQLAdd =
			"SELECT * FROM tbl_radio ORDER BY RAND() LIMIT 10";

		$query = mysqli_query($kon, $SQLAdd);
		if (mysqli_num_rows($query) > 0){
			$respon['radio_status'] = 1;
			while ($list = mysqli_fetch_assoc($query)) {
				$respon['radio'][] = $list;
			}

			$SQLAdd =
				"SELECT ra.* FROM tbl_radio ra
				LEFT JOIN tbl_favorite fa ON fa.id_radio = ra.id
				LEFT JOIN tbl_device_id dev ON dev.id = fa.id_user
				WHERE dev.fcm = '".$id_device."' ORDER BY favorite DESC LIMIT 10";

			$query = mysqli_query($kon, $SQLAdd);
			if (mysqli_num_rows($query) > 0){
				$respon['my_favorite_status'] = 1;
				while ($list = mysqli_fetch_assoc($query)) {
					$respon['my_favorite'][] = $list;
				}
			} else {
				$respon['my_favorite_status'] = 0;
				$respon['my_favorite'][] = 'null';	
			}

			$SQLAdd =
				"SELECT * FROM tbl_radio ORDER BY favorite DESC LIMIT 10";

			$query = mysqli_query($kon, $SQLAdd);
			if (mysqli_num_rows($query) > 0){
				$respon['favorite_status'] = 1;
				while ($list = mysqli_fetch_assoc($query)) {
					$respon['favorite'][] = $list;
				}
			} else {
				$respon['favorite_status'] = 0;
				$respon['favorite'][] = 'null';		
			}

			/*$SQLAdd =
				"SELECT ra.* FROM tbl_radio ra
				LEFT JOIN tbl_favorite fa ON fa.id_radio = ra.id
				LEFT JOIN tbl_device_id dev ON dev.id = fa.id_user
				GROUP BY listener_id ORDER BY COUNT(listener_id) DESC";

			$query = mysqli_query($kon, $SQLAdd);
			if (mysqli_num_rows($query) > 0){
				$respon['listener_status'] = 1;
				while ($list = mysqli_fetch_assoc($query)) {
					$respon['listener'][] = $list;
				}
			} else {
				$respon['listener_status'] = 0;
				$respon['listener'][] = 'null';		
			}

			$SQLAdd =
				"SELECT * FROM tbl_radio ORDER BY RAND() DESC LIMIT 10";

			$query = mysqli_query($kon, $SQLAdd);
			if (mysqli_num_rows($query) > 0){
				$respon['listener_all_status'] = 1;
				while ($list = mysqli_fetch_assoc($query)) {
					$respon['listener_all'][] = $list;
				}
			} else {
				$respon['listener_all_status'] = 0;
				$respon['listener_all'][] = 'null';		
			}*/

			$respon['listener_status'] = 0;
			$respon['listener'][] = 'null';	
			$respon['listener_all_status'] = 0;
			$respon['listener_all'][] = 'null';	

		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'data tidak ditemukan';	
		}

		$SQLAdd =
			"SELECT * FROM tbl_device_id WHERE fcm = '".$id_device."'";
		$query = mysqli_query($kon, $SQLAdd);
		if (mysqli_num_rows($query) > 0){
			fnUpdateItem($kon,
				"tbl_device_id",
				"udt = '".$tgl."'",
				"fcm = '".$id_device."'"
			); 	
		} else {
			fnInsertItem($kon,
				"tbl_device_id",
				"fcm",
				"'".$id_device."'"
			);		
		}

		return $respon;
	}

    function fnUpdateFavorite($kon, $id_device, $id_radio){
		$index = 0;
		
		$SQLAdd =
			"SELECT id FROM tbl_device_id WHERE fcm = '".$id_device."'";

		$query = mysqli_query($kon, $SQLAdd);

		if (mysqli_num_rows($query) > 0){
			$list = mysqli_fetch_array($query);
			$SQLAdd =
				"SELECT * FROM tbl_favorite WHERE id_user = '".$list['id']."' AND id_radio = '".$id_radio."'";
			$query = mysqli_query($kon, $SQLAdd);
			if (mysqli_num_rows($query) > 0){
				fnDeleteItemWhere($kon,
					"tbl_favorite",
					"id_user = '".$list['id']."' AND id_radio = '".$id_radio."'"
				);

				$respon[$index]['status'] = 0;	
			} else {
				fnInsertItem($kon,
					"tbl_favorite",
					"id_user, id_radio",
					"'".$list['id']."', '".$id_radio."'"
				);

				$respon[$index]['status'] = 1;	
			}
		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'Gagal Menambahkan Favorite';		
		}

		return $respon;
	}

    function fnUpdateListener($kon, $id_device, $id_radio){
		$index = 0;
		
		$respon = 	fnUpdateItem($kon,
						"tbl_device_id",
						"listener_id = '".$id_radio."'",
						"fcm = '".$id_device."'"
					); 	

		return $respon;
	}

    function fnSendNotif($kon, $nm, $jabatan, $alamat, $tujuan, $keterangan){
		$index = 0;
		
		$txt = $tujuan;
		if ($tujuan == 'Lainnya') {
			$txt = $keterangan;
		}

		$txt = 
			$nm." [".$jabatan."] datang dari ".$alamat.", tujuan kedatangan adalah ".$txt;

		$SQLAdd =
			"SELECT * FROM tbl_device_id ORDER BY cdt DESC";

		$query = mysqli_query($kon, $SQLAdd);

		if (mysqli_num_rows($query) > 0){
			while ($list = mysqli_fetch_array($query)) {
				sendPush($list['device_id'], 'Ada Tamu!', $txt, 'https://www.blangkon.net/API/APITamu/files/06052021222736310.png', 'https://www.blangkon.net/API/APITamu/files/06052021222736310.png');
			}
		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'DATA DETAIL TRANSAKSI TIDAK TERSEDIA';	
		}

		return $respon;
	}
	
    function fnBulkSendPush($kon, $title, $body, $icon, $url){
		$index = 0;
		
		$SQLAdd =
			"SELECT * FROM tbl_device_id ORDER BY udt DESC";

		$query = mysqli_query($kon, $SQLAdd);

		if (mysqli_num_rows($query) > 0){
			while ($list = mysqli_fetch_array($query)) {
				$respon[$index]['result'] = sendPush($list['fcm'], $title, $body, $icon, $url);
				$respon[$index]['fcm'] = $list['fcm'];	
				$index++;
			}
		} else {
			$respon[$index]['result'] = 'null';	
			$respon[$index]['pesan'] = 'MAAF, BELUM ADA DATA';	
		}

		return $respon;
	}
	
    
?>