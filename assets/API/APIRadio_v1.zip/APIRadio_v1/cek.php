<?php
	set_time_limit(0);
	header("Content-Type: application/json; charset=UTF-8");

    include_once 'config/config.php';
    include_once 'config/function.php';
    include_once 'config/loadData.php';

    $dir = __DIR__ ;

	$index = 0;
	$respon = array(); 

    $SQLAdd =
			"SELECT * FROM tbl_radio";
            $query = mysqli_query($koneksi, $SQLAdd);

    if (mysqli_num_rows($query) > 0){
        $total_data = mysqli_num_rows($query);
        while ($list = mysqli_fetch_array($query)) {
            $respon[$index]['radio_name'] = $list['radio_name'];
            $respon[$index]['stream_url'] = $list['stream_url'];

            $ch = curl_init($list['stream_url']);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, 5000);

            curl_exec($ch);
            if (!curl_errno($ch)) {
                $info = curl_getinfo($ch);
                $respon[$index]['status'] = 'online';
                $respon[$index]['info'] = 'Took '.$info['total_time'].' seconds to send a request to '.$info['url']."\n";
                
                $respon[$index]['exe'] = fnUpdateItem($koneksi,
                    "tbl_radio",
                    "status = 1",
                    "id = '".$list['id']."'"
                ); 
            } else {
                $respon[$index]['status'] = 'offline';
                $respon[$index]['info'] = 'error';

                $respon[$index]['exe'] = fnUpdateItem($koneksi,
                    "tbl_radio",
                    "status = 0",
                    "id = '".$list['id']."'"
                ); 
            }

            curl_close($ch);

            $index++;

            $data['url'] = $list['stream_url'];
            $data['position'] = $index;
            $data['total_data'] = $total_data; 

            $json = json_encode($data);
            file_put_contents($dir."/count.json", $json);
        }
    } else {
        $respon[$index]['result'] = 'null';	
        $respon[$index]['pesan'] = 'MAAF, BELUM ADA DATA';	
    }
    
	
	echo json_encode($respon,JSON_PRETTY_PRINT);
    
    
    
?>