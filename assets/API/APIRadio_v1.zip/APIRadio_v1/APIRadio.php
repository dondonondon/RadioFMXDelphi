<?php
    include_once 'config/config.php';
    include_once 'config/function.php';
    include_once 'config/loadData.php';
	
	header("Content-Type: application/json; charset=UTF-8");
    $get_folder = __DIR__ ; 

	$index = 0;
	$respon = array(); 
	$keyAkses = 'apiapi';
	$sign = 'blangkonfa2019';

	if (empty($_GET['act'])) {
		$respon[$index]['result'] = 'null';
		$respon[$index]['pesan'] = 'Invalid action';
	} else {
		$headers = apache_request_headers();
		$headers['key'] = 'apiapi';

		if (empty($headers['key'])) {
			$respon[$index]['result'] = 'null';
			$respon[$index]['pesan'] = 'Invalid key';
		} else {
			if ($headers['key'] == $keyAkses){
				if (!$koneksi) {
					$respon[$index]['result'] = 'null';
					$respon[$index]['pesan'] = 'MAAF GAGAL MENGHUBUNGKAN DENGAN SERVER';	
				} else {
					if ($_GET['act'] == 'deleteItem'){ 
						$id = $_POST['id'];
						$tbl = $_POST['tbl'];
						
						if (fnDeleteItem($koneksi, $id, $tbl)) {
							$respon[$index]['result'] = "SUKSES";
							$respon[$index]['pesan'] = 'DATA BERHASIL DI HAPUS';
						} else {
							$respon[$index]['result'] = "null";
							$respon[$index]['pesan'] = 'MAAF, DATA GAGAL HAPUS';
						}
					} elseif ($_GET['act'] == 'deleteItemWhere') {
						$respon = fnDeleteItemWhere($koneksi, $_POST['tbl'], $_POST['isWhere']);
					} elseif ($_GET['act'] == 'insertItem') {
						$respon = fnInsertItem($koneksi, $_POST['tbl'], $_POST['kol'], $_POST['val']);
					} elseif ($_GET['act'] == 'insertItemIsNull') {
						$respon = fnInsertItemIsNull($koneksi, $_POST['tbl'], $_POST['kol'], $_POST['val'], $_POST['isWhere']);
					} elseif ($_GET['act'] == 'insertItemIsNotNull') {
						$respon = fnInsertItemIsNotNull($koneksi, $_POST['tbl'], $_POST['kol'], $_POST['val'], $_POST['isWhere']);
					} elseif ($_GET['act'] == 'updateItem') {
						$respon = fnUpdateItem($koneksi, $_POST['tbl'], $_POST['val'], $_POST['isWhere']);	
					} elseif ($_GET['act'] == 'updateItemIsNull') {
						$respon = fnUpdateItemIsNull($koneksi, $_POST['tbl'], $_POST['val'], $_POST['id'], $_POST['isWhere']);
					} elseif ($_GET['act'] == 'updateItemIsNotNull') {
						$respon = fnUpdateItemIsNotNull($koneksi, $_POST['tbl'], $_POST['val'], $_POST['id'], $_POST['isWhere']);
					} elseif ($_GET['act'] == 'loadRadio') {
						#$respon = fnLoadRadio($koneksi);
						$respon = json_decode(file_get_contents('response.json'), TRUE);
					} elseif ($_GET['act'] == 'findRadio') {
						$respon = fnFindRadio($koneksi, $_POST['keyword']);
					} elseif ($_GET['act'] == 'loadHome') {
						$respon = fnLoadHome($koneksi, $_POST['id_device']);
					} elseif ($_GET['act'] == 'updateFavorite') {
						$respon = fnUpdateFavorite($koneksi, $_POST['id_device'], $_POST['id_radio']);
					} elseif ($_GET['act'] == 'updateListener') {
						$respon = fnUpdateListener($koneksi, $_POST['id_device'], $_POST['id_radio']);
					} elseif ($_GET['act'] == 'loadMyFavorite') {
						$respon = fnMyFavorite($koneksi, $_POST['id_device']);
					} elseif ($_GET['act'] == 'loadRadioLimit') {
						$respon = fnLoadRadioLimit($koneksi, $_GET['limit']);
					} elseif ($_GET['act'] == 'loadFavorite') {
						$respon = fnFavorite($koneksi);
					} elseif ($_GET['act'] == 'getSetting') {
						$respon = fnGetSetting($koneksi);
					} elseif ($_GET['act'] == 'sendPush') {
						$respon = sendPush($_POST['to'], $_POST['title'], $_POST['body'], $_POST['icon'], $_POST['url']);
					} elseif ($_GET['act'] == 'bulkSendPush') {
						$respon = fnBulkSendPush($koneksi, $_POST['title'], $_POST['body'], $_POST['icon'], $_POST['url']);
					} else {
						$respon[$index]['result'] = "null";
						$respon[$index]['pesan'] = 'Invalid action';	
					}
				}
			} else {
				$respon[$index]['result'] = 'null';
				$respon[$index]['pesan'] = 'Invalid key';	
			}	
		}

		
	}
	
	echo json_encode($respon,JSON_PRETTY_PRINT);
?>