<?php
    window.header("location:https://www.blangkon.net");
?>